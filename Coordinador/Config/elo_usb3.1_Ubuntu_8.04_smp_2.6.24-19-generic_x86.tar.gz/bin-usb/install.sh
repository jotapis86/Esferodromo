#!/bin/sh
if [ -f /elo/elousb.o ]; then
 echo "Kernel base 2.4, install module elousb.o"
 install -m 644 /elo/elousb.o /lib/modules/`uname -r`/kernel/drivers/elousb.o
else
 if [ -f /elo/elousb.ko ]; then
  echo "Kernel base 2.6, install module elousb.ko"
  install -m 644 /elo/elousb.ko /lib/modules/`uname -r`/kernel/drivers/elousb.ko
 else
  echo "Module "elousb" missing..!!"
 fi
fi
/sbin/depmod -q
