#include <linux/poll.h>
//#include <linux/config.h>
#include <linux/autoconf.h>
#include <linux/version.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/timer.h>
#include <linux/fs.h>
#include <asm/uaccess.h>
#include <linux/proc_fs.h>
#include <linux/slab.h>
#include <linux/usb.h>

int elo_usb_register(struct usb_driver * driver);
void elo_usb_deregister(struct usb_driver * driver);

