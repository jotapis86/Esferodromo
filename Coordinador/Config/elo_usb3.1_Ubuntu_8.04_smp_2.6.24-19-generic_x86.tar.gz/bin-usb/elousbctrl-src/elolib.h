
int elo_usb_control_msg(struct usb_device *dev, unsigned int pipe,
	__u8 request, __u8 requesttype, __u16 value, __u16 index,
	void *data, __u16 size, int timeout);


#ifndef LKV_24
int elo_usb_submit_urb(struct urb *urb, int mem_flags);
void * elo_usb_buffer_alloc(struct usb_device *dev, size_t size,
	int mem_flags, dma_addr_t *dma);
#else 
int elo_usb_submit_urb(struct urb *urb);
#endif
int elo_usb_unlink_urb(struct urb *urb);


int elo_printk(const char*fmt, ...);



void elo_usb_fill_int_urb(struct urb *urb,
				     struct usb_device *dev,
				     unsigned int pipe,
				     void *transfer_buffer,
				     int buffer_length,
				     usb_complete_t complete,
				     void *context,
				     int interval);

void * elo_kmalloc(size_t size, int priority);

void elo_usb_set_intfdata(struct usb_interface *intf, void *data);

void *elo_usb_get_intfdata(struct usb_interface *intf);

void elo_usb_deregister(struct usb_driver * driver);

void *elo_memset(void *s, int c, size_t n);

int elo_usb_register(struct usb_driver * driver);


void elo_kfree(void * __ptr);

void elo_usb_free_urb(struct urb *urb);

#ifndef LKV_24
struct urb *elo_usb_alloc_urb(int iso_packets, int mem_flags);

void elo_usb_buffer_free(struct usb_device *dev, size_t size,
	void *addr, dma_addr_t dma);
#else
struct urb *elo_usb_alloc_urb(int iso_packets);
#endif
