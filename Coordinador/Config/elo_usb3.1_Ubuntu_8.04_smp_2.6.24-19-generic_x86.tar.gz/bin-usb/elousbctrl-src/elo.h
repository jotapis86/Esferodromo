#include <linux/usb.h>

#define ELO_QUEUE_SZ	4000

#define USB_VENDOR_ID_ELOTOUCH	0x04E7
#define ELO_BUFFER_SIZE		8

struct elousb_device {							


    struct urb *input_urb;						
#ifdef LKV_24
	char urb_buffer[ELO_BUFFER_SIZE];						
#else
	char *urb_buffer;						
	dma_addr_t urb_dma;						
#endif


    struct usb_device *device;						// usb device
    struct usb_interface *interface;			    // usb interface
};

struct hid_class_descriptor {
	__u8  bDescriptorType;
	__u16 wDescriptorLength;
} __attribute__ ((packed));

struct hid_descriptor {
	__u8  bLength;
	__u8  bDescriptorType;
	__u16 bcdHID;
	__u8  bCountryCode;
	__u8  bNumDescriptors;

	struct hid_class_descriptor desc[1];
} __attribute__ ((packed));

/*
struct elo_usb_packet
{
  unsigned short status;
  unsigned short x;
  unsigned short y;
  unsigned short z;
};


struct elo_control_if
{
	void (*translate_point)(struct elo_usb_packet * touch_packet);	
};*/

#ifndef LKV_24
struct elousb_device *hw_init(struct usb_interface *intf);
void elousb_disconnect(struct usb_interface *intf);
int elousb_probe (struct usb_interface *intf, const struct usb_device_id *id);
#else
struct elousb_device *hw_init(struct usb_device *dev, unsigned int ifnum);
void elousb_disconnect(struct usb_device *dev, void *ptr);
void* elousb_probe(struct usb_device *dev, unsigned int ifnum,
		       const struct usb_device_id *id);
#endif

//void elo_register_control(struct elo_control_if * control_if);
int elousb_ss(unsigned char request, unsigned char * command);

