// main.c : Main file for elocontrol driver project.
//
// Copyright(c) 2003  Elo TouchSystems, Inc., all rights reserved.
// Ragini Prasad
//
// Linux control driver model
//
// 
// -----------------------------------------------------------------------------

#include "elocontrol.h"
#include "elo.h"
#include "elolib.h"

#define KER

#define ELO_TOUCH_DATA_BUFFER_SIZE 8
#define MAX_STR  256
#define SECONDS_COUNT 1

#define BOOL                    int 
#define elocontrol_MAJOR        0
#define eloconfig_MAJOR         0
#define elocmd_MAJOR            0
#define elorsp_MAJOR            0

#define ONTOUCHMODE                     0x01
#define RELEASEMODE                     0x04
#define DRAGMODE                        0x07

#define DEFAULT_DRAG                            10

enum
{
  FALSE=0,
  TRUE=1
} ;

enum
{
   DBG_NONE=0,
   DBG_INPUT_PIPE=1,
   DBG_PROC_PIPE,
   DBG_SERIALCMD_PIPE,
   DBG_CONFIG_PIPE,
   DBG_ALL
};

struct elo_usb_packet
{
    unsigned short status;
    unsigned short x;
    unsigned short y;
    unsigned short z;
};

struct elo_control_if
 {
    void (*translate_point)(struct elo_usb_packet * touch_packet);  
 };


//				Static Data
//--------------------------------------------------------------------------------
//#define schedule do_schedule
 BOOL bSetDeviceType=TRUE;

unsigned long bytes_in_buffer=0;

struct elo_usb_packet elodatabuffer[ELO_QUEUE_SZ] ;
unsigned int databufferhead=0 ;	// head is read position
unsigned int databuffertail=0 ;	// tail is write position

wait_queue_head_t elocontrol_wq;
wait_queue_head_t elocontrol_wqgetpt ;
struct fasync_struct *gfasync;

int elocontrol_major=elocontrol_MAJOR;
char *elocontrol_name="/input/elo";

extern wait_queue_head_t eloserialcmd_wq,eloserialrsp_wq ;
int eloconfig_major=eloconfig_MAJOR;
char *eloconfig_name="/elo/eloconfig";
struct fasync_struct *g_serialcmd_fasync;

int eloserialcmd_major=elocmd_MAJOR;
char *eloserialcmd_name="/elo/cmd_fifo";

// externs
extern wait_queue_head_t eloconfig_wq ;
struct fasync_struct *g_config_fasync;
extern int bytes_in_config_buffer ;

// Used for getpoints
BOOL bGetPointFlag=FALSE ;

// timer
struct timer_list timer, reset_data_timer;
unsigned long up_seconds = 0 ;
BOOL signaled_data = FALSE ;
BOOL bSerialDevice=FALSE;
			
// debug
int debug = 0;

// proc entries
unsigned long NoOfOpen=0, NoOfClose=0, NoOfReads=0, NoOfWrites=0;

// mode
int gMode = DRAGMODE ;
int gDrag = DEFAULT_DRAG ;

//char gSerialName[MAX_STR]="ttyS0";
char *gSerialName = "ttyS0";

// USB Driver Code
                                                                                                                  
#undef DEBUG_DATA
#define DEBUG
                                                                                                                  
/*#define DRIVER_VERSION "v1.0"
#define DRIVER_AUTHOR "Massoud Navab"
#define DRIVER_DESC "USB driver"
#define DRIVER_LICENSE "GPL" */
                                                                                                                  
void elocontrol_XlateTouch( struct elo_usb_packet *pelo_usb_packet );
#ifndef LKV_24
void urb_completion_irq(struct urb *urb, struct pt_regs *regs);
#else
void urb_completion_irq(struct urb *urb);
#endif
                                                                                                                  
void hw_release(struct elousb_device *device);

struct usb_device_id vendor_id [] =
{
        { .match_flags = USB_DEVICE_ID_MATCH_VENDOR, .idVendor = USB_VENDOR_ID_ELOTOUCH },
    { }
};
                                                                                                                  
MODULE_DEVICE_TABLE (usb, vendor_id);
                                                                                                                  
struct usb_driver elousb_driver =
{
   // .owner =  THIS_MODULE,
        .name =         "elo_touch_usb",
        .probe =        elousb_probe,
        .disconnect =   elousb_disconnect,
        .id_table =     vendor_id,
};
                                                                                                                  
struct elousb_device *  elodev;                 

// Functions
                                                                                                                  
// standard entry points
                                                                                                                  
#ifndef LKV_24
int elousb_probe (struct usb_interface *intf, const struct usb_device_id *id)
{
                                                                                                                  
    elo_printk("HID probe called for ifnum %d", intf->altsetting->desc.bInterfaceNumber);
                                                                                                                  
    if (!hw_init(intf))
    {
         return -EIO;
    }
    else
    {
        return 0;
    }
}
#else
void* elousb_probe(struct usb_device *dev, unsigned int ifnum,
                       const struct usb_device_id *id)
{
                                                                                                                  
       elo_printk("HID probe called for ifnum %d", ifnum);
       return hw_init(dev,ifnum);
                                                                                                                  
}
#endif
                                                                                                                  
                                                                                                                  
                                                                                                                  
#ifndef LKV_24
void elousb_disconnect(struct usb_interface *intf)
{
        struct elousb_device *device = elo_usb_get_intfdata (intf);
                                                                                                                  
                                                                                                                  
        if (!device)
    {
        return;
    }
                                                                                                                  
        elo_usb_set_intfdata(intf, NULL);
        elo_usb_unlink_urb(device->input_urb);
        hw_release(device);
                                                                                                                  
        elo_printk("elousb_disconnect done.\n");
    return;
}
#else
void elousb_disconnect(struct usb_device *dev, void *ptr)
{
        struct elousb_device *device = (struct elousb_device *)ptr;
                                                                                                                  
    if (!device)
    {
        return;
    }
                                                                                                                  
    elo_usb_unlink_urb(device->input_urb);
    hw_release(device);
                                                                                                                  
    elo_printk("elousb_disconnect done.\n");
    return;
}
#endif

// -----------------------------------------------------------------------------
//			Command line params
// -----------------------------------------------------------------------------

// module information
MODULE_AUTHOR("Elo TouchSystems.");
MODULE_DESCRIPTION("Elo TouchSystems main driver module");
// MODULE_LICENSE("GPL");
MODULE_LICENSE("Elo TouchSystems, Inc., All rights reserved. Copyright(c) 2008");

module_param(debug,int,0);
// MODULE_PARM(debug,"i");
MODULE_PARM_DESC(debug, "Debug print for the device" ) ;

module_param(elocontrol_major,int,0);
// MODULE_PARM(elocontrol_major,"i");
MODULE_PARM_DESC(elocontrol_major, "Major Number for the data device" ) ;

module_param(eloconfig_major,int,0);
// MODULE_PARM(eloconfig_major,"i");
MODULE_PARM_DESC(eloconfig_major, "Major Number for the config device" ) ;

module_param(eloserialcmd_major,int,0);
// MODULE_PARM(eloserialcmd_major,"i");
MODULE_PARM_DESC(eloserialcmd_major, "Major Number for the serial device" ) ;

module_param(gSerialName,charp,0);
// MODULE_PARM(gSerialName,"s");
MODULE_PARM_DESC(gSerialName, "Serial port name: ttyS0 for /dev/ttyS0, ttyS1 for /dev/ttyS1" ) ;

module_param(gMode,int,0);
// MODULE_PARM(gMode,"i");
MODULE_PARM_DESC(gMode, "Set mode for the device : valid modes 1: Click on Touch, 4: Click on Release, 7: Mousemode" ) ;

module_param(gDrag,int,0);
// MODULE_PARM(gDrag,"i");
MODULE_PARM_DESC(gDrag, "Set dragdelay for the device : default is 10" ) ;

// -----------------------------------------------------------------------------
//			Function Prototype
// -----------------------------------------------------------------------------
int elocontrol_writetouch( const char *buf, size_t count ) ;
ssize_t elocontrol_read( struct file *file, char *buf, size_t count, loff_t *offset);
ssize_t elocontrol_write( struct file *file, const char *buf, size_t count, loff_t *offset) ;
int elocontrol_fasync(int fd, struct file *file, int on) ;

unsigned int elocontrol_poll(struct file *file, poll_table *wait) ;
int elocontrol_ioctl( struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg ); 
int elocontrol_open( struct inode *inode, struct file *file);
int elocontrol_release( struct inode *inode, struct file *file ) ;
int read_procmem( char *buf, char **start, off_t offset, int len, int *eof, void *data ); 
void SaveParametersToConfigFile(void);
void InitValues(void);
unsigned long elo_copy_to_user(void * to, void * from , unsigned long n);
unsigned long elo_copy_from_user(void * to, void * from , unsigned long n);
void elo_getpoints_wait_event(void);
void elousb_get_descriptors(struct elousb_device * device);

void my_timer_function(unsigned long data);
int eloconfig_open( struct inode *inode, struct file *file) ;
int eloconfig_release( struct inode *inode, struct file *file ) ;
ssize_t eloconfig_read( struct file *file, char *buf, size_t count, 
								loff_t *offset) ;
ssize_t eloconfig_write( struct file *file, const char *buf, size_t count, 
								loff_t *offset) ;
int eloconfig_fasync(int fd, struct file *file, int on) ;
unsigned int eloconfig_poll(struct file *file, poll_table *wait) ;

int eloserialcmd_open( struct inode *inode, struct file *file) ;
int eloserialcmd_release( struct inode *inode, struct file *file ) ;
ssize_t eloserialcmd_read( struct file *file, char *buf, size_t count,loff_t *offset);
ssize_t eloserialcmd_write( struct file *file, const char *buf, size_t count,loff_t *offset) ;
int eloserialcmd_fasync(int fd, struct file *file, int on) ;
unsigned int eloserialcmd_poll(struct file *file, poll_table *wait) ;
void debugprintk( int level, char *szBuff );


//----------------------------------------------------------------------------
struct file_operations elocontrol_fops = {
	owner:	THIS_MODULE,
	read:	elocontrol_read,
	write:	elocontrol_write,
	poll:	elocontrol_poll,
	ioctl:	elocontrol_ioctl,
	open:	elocontrol_open,
	release:elocontrol_release,
	fasync:	elocontrol_fasync,	
};

struct file_operations eloconfig_fops = {
	owner:	THIS_MODULE,
	read:	eloconfig_read,
	write:	eloconfig_write,
	poll:	eloconfig_poll,
	open:	eloconfig_open,
	release:eloconfig_release,
	fasync:	eloconfig_fasync,	
};

struct file_operations eloserialcmd_fops = {
	owner:	THIS_MODULE,
	read:		eloserialcmd_read,
	write:	eloserialcmd_write,
	open:		eloserialcmd_open,
	release:	eloserialcmd_release,
	poll:		eloserialcmd_poll,
	fasync:	eloserialcmd_fasync,	
};

//----------------------------------------------------------------------------
// touch data read pipe is /dev/input/elo
// Touch data read entry point 
// return data available from the touch data buffer
ssize_t elocontrol_read( struct file *file, char *buf, size_t count, 
								loff_t *offset)
{
	char szBuff[MAX_STR];
	int retval = 0;
	struct elo_usb_packet *tmpbuffer ;
	int readcount, tmpRead  ;
	char *tmpreadbuf;
		
	// If debugging is enabled print the function param
	sprintf(szBuff,"elocontrol_read: In Count=%d bytes_in_buffer=%u databufferhead=%d\n", count , (int)bytes_in_buffer, databuffertail);
	debugprintk(DBG_INPUT_PIPE,szBuff);
	
#ifndef KER
	//if(count > bytes_in_buffer)
	if(ELO_TOUCH_DATA_BUFFER_SIZE > bytes_in_buffer)
	{
	
		while ( ELO_TOUCH_DATA_BUFFER_SIZE > bytes_in_buffer) {

			if (file->f_flags & O_NONBLOCK) {
				debugprintk( DBG_INPUT_PIPE, "Flag nonblock\n" ) ;
				retval = -EAGAIN;
				break;
			}
			if (signal_pending(current)) {
				debugprintk( DBG_INPUT_PIPE, "signal pending current\n") ;
				retval = -ERESTARTSYS;
				break;
			}
			interruptible_sleep_on(&elocontrol_wq);
		}
		
		current->state = TASK_RUNNING;
	}
#else
	if(ELO_TOUCH_DATA_BUFFER_SIZE > bytes_in_buffer)
	{
		if (file->f_flags & O_NONBLOCK) {
			debugprintk( DBG_INPUT_PIPE, "Flag nonblock\n" ) ;
			retval = -EAGAIN;
		}
		else
		retval=wait_event_interruptible(elocontrol_wq,	(ELO_TOUCH_DATA_BUFFER_SIZE < bytes_in_buffer)) ;
	}

#endif	
	if (retval)
	{
		debugprintk( DBG_INPUT_PIPE, "read: Error from retval \n" ) ;
		return retval;
	}

	tmpRead =0 ;
	
	if( count > bytes_in_buffer )
	{
		count = readcount = bytes_in_buffer ;
	}
	else
		readcount = count ;
		
	tmpreadbuf=buf;
	while( readcount >= ELO_TOUCH_DATA_BUFFER_SIZE )
	{
		tmpbuffer = elodatabuffer + databufferhead ;
		if(elo_copy_to_user(tmpreadbuf,(elodatabuffer + databufferhead), ELO_TOUCH_DATA_BUFFER_SIZE))
		{
			debugprintk(DBG_INPUT_PIPE,"elocontrol error in elo_copy_to_user success\n" );
			return -EFAULT;
		} 
		databufferhead ++ ;
		if ( databufferhead >= ELO_QUEUE_SZ ) databufferhead=0 ;
		readcount -= ELO_TOUCH_DATA_BUFFER_SIZE ;
		tmpRead += ELO_TOUCH_DATA_BUFFER_SIZE ;
		tmpreadbuf += ELO_TOUCH_DATA_BUFFER_SIZE ;
	}
	sprintf( szBuff, "After read tmpRead=%d, bytes_in_buffer=%d \n", (int)tmpRead, (int)bytes_in_buffer ) ;
	debugprintk( DBG_INPUT_PIPE, szBuff ) ;
	{
	int iLoop ; 
	int cnt ;
	cnt=tmpRead/ELO_TOUCH_DATA_BUFFER_SIZE;
	for( iLoop=0;iLoop<cnt;iLoop++)
	{
		tmpbuffer = (struct elo_usb_packet *)(buf + ( ELO_TOUCH_DATA_BUFFER_SIZE * iLoop )) ;	
		sprintf( szBuff, "elocontrol: Buff state=%x x=%x y=%x \n", tmpbuffer->status, tmpbuffer->x , tmpbuffer->y );
		debugprintk(DBG_INPUT_PIPE,szBuff);
	}
	}
	count=tmpRead;
	bytes_in_buffer -= tmpRead;
	if( bytes_in_buffer < 0 )
		bytes_in_buffer = 0 ;
	return tmpRead; 
}

//----------------------------------------------------------------------------
// Implements asynchronous io for elocontrol /dev/input/elo pipe
int elocontrol_fasync(int fd, struct file *file, int on)
{
	int retval;
	retval = fasync_helper(fd, file, on, &gfasync);
	return retval < 0 ? retval : 0;
}

//----------------------------------------------------------------------------
// Implements polling for elocontrol /dev/input/elo pipe
unsigned int elocontrol_poll(struct file *file, poll_table *wait)
{
	poll_wait(file, &elocontrol_wq, wait);
	if (bytes_in_buffer >=  ELO_TOUCH_DATA_BUFFER_SIZE )
		return POLLIN | POLLRDNORM;
	return 0;
}

//---------------------------------------------------------------------------
// Wrapper function for copy_to_user function

unsigned long elo_copy_to_user(void * to, void * from , unsigned long n)
{
    return copy_to_user(to, from, n);
}


//---------------------------------------------------------------------------
// Wrapper function for copy_from_user function

unsigned long elo_copy_from_user(void * to, void * from , unsigned long n)
{
    return copy_from_user(to, from, n);
}

//---------------------------------------------------------------------------
// Wrapper function for getpoints IOCTL wait function

void elo_getpoints_wait_event(void)
{
  wait_event_interruptible(elocontrol_wqgetpt,bGetPointFlag==FALSE) ;
}

//---------------------------------------------------------------------------
// Wrapper function for kill_fasync function

void elo_kill_fasync(struct fasync_struct ** fas,int a, int b)
{
  kill_fasync( fas, a, b);
}

//---------------------------------------------------------------------------
// Wrapper function for wake_up_interruptible function

void elo_wake_up_interruptible( wait_queue_head_t * qh) 
{
  wake_up_interruptible( qh ) ;
}

//---------------------------------------------------------------------------
// Wrapper function for usb_sndctrlpipe function

unsigned int elo_usb_sndctrlpipe(struct usb_device *dev, unsigned int endpoint)
{
    return usb_sndctrlpipe(dev, endpoint);
}

//---------------------------------------------------------------------------
// Wrapper function for usb_rcvctrlpipe function

unsigned int elo_usb_rcvctrlpipe(struct usb_device *dev, unsigned int endpoint)
{
    return usb_rcvctrlpipe(dev, endpoint);
}

//---------------------------------------------------------------------------
// Wrapper function for usb_rcvintpipe function

unsigned int elo_usb_rcvintpipe(struct usb_device *dev, unsigned int endpoint)
{
    return usb_rcvintpipe(dev, endpoint);
}

//---------------------------------------------------------------------------
// Wrapper function for interface_to_usbdev function

struct usb_device * elo_interface_to_usbdev(struct usb_interface * intf)
{
    return interface_to_usbdev(intf);
}   

//---------------------------------------------------------------------------
//----------------------------------------------------------------------------
// Implements open entry point for elocontrol /dev/input/elo device
int elocontrol_open( struct inode *inode, struct file *file)
{
	char szBuff[MAX_STR];

	// Increment module usage cnt
	//MOD_INC_USE_COUNT;

	if( file->f_mode & FMODE_READ )
	{
		debugprintk(DBG_INPUT_PIPE, "elocontrol_open: opened in read mode\n" );
	}
	
	// No of opens
	NoOfOpen++;
	
	if( file->f_mode & FMODE_WRITE )
	{
		debugprintk( DBG_INPUT_PIPE,"elocontrol_open: opened in write mode\n" );
	}	

	sprintf( szBuff, "Major no %u minor no %u \n" , MAJOR(inode->i_rdev), 
		MINOR( inode->i_rdev));
	debugprintk( DBG_INPUT_PIPE,szBuff ) ;


	return 0;
}


//----------------------------------------------------------------------------
// Implements close entry point for elocontrol /dev/input/elo device
int elocontrol_release( struct inode *inode, struct file *file ) 
{
	// If debugging is enabled print the function param
	debugprintk(DBG_INPUT_PIPE, "elocontrol_release: In\n" ) ;

	elocontrol_fasync(-1, file, 0);

	// Decrement module usage cnt
	//MOD_DEC_USE_COUNT;

	// No of close 
	NoOfOpen--;

	return 0;
}

//----------------------------------------------------------------------------
// Implements timer function for clearing data in the touch data device
/*
Notes on jiffy 
Basic packet of kernel time, around 10ms on x86. Related to HZ, the 
basic resolution of the operating system. The timer interrupt is 
raised each 10ms, which then performs some h/w timer related stuff, 
and marks a couple of bh's ready to run if applicable.
*/
void my_timer_function( unsigned long data )
{
   int DevCnt ;
	unsigned long *sec_count = (unsigned long *) data;
	*sec_count += SECONDS_COUNT ;

	// If debugging is enabled print the function param
	//if data was not read set this to 0	
	
	if( bytes_in_buffer > 0 )
	{
		elo_kill_fasync(&gfasync, SIGIO, POLL_IN);
		elo_wake_up_interruptible( &elocontrol_wq ) ;
	}  

	if( bytes_in_buffer <= 0 )
		signaled_data = FALSE ;

	// if data is not picked up by any client reset the pointers
	// if anyone is intrested in reading data in the meanwhile then do not do this 
	// if device is opened for read then dont reset data
	if( bSerialDevice==TRUE  )
		DevCnt = 1 ;
	else
		DevCnt = 0;
		
	if( ( NoOfOpen <= DevCnt ) && ( bytes_in_buffer > 0 ) )
	{
		bytes_in_buffer=0;
		// head is read position & tail is write position
		databufferhead=databuffertail=0 ;	
		debugprintk(DBG_INPUT_PIPE, "Reset data buffer in reset_data_timer_function" );
	}  

//	timer.expires = jiffies + HZ * SECONDS_COUNT ;
//	timer.expires = jiffies + SECONDS_COUNT ;
	timer.expires = jiffies + HZ/33 ;
	add_timer(&timer);
}

//----------------------------------------------------------------------------
// Structure used to register callback with elousb
struct elo_control_if elousbif={
	translate_point: elocontrol_XlateTouch ,
};


//----------------------------------------------------------------------------
#ifndef LKV_24
void urb_completion_irq(struct urb *urb, struct pt_regs *regs)
#else
void urb_completion_irq(struct urb *urb)
#endif
{
        unsigned char  * ucp = ( unsigned char *) urb->transfer_buffer;
        unsigned short  * usp = ( unsigned short *) urb->transfer_buffer;
        struct elo_usb_packet touch_packet;
                                                                                                                  
#ifndef LKV_24
        int                     status;
#endif
                                                                                                                  
  if (urb->status)
  {
        elo_printk("failure status in urb %x",urb->status);
        return;
  }
 touch_packet.status = (unsigned short)ucp[1];
  touch_packet.x = usp[1];
  touch_packet.y = usp[2];
  touch_packet.z = usp[3];
  //elo_printk(" status %x  x %x  y %x  z %x \n", touch_packet.status,touch_packet.x, touch_packet.y, touch_packet.z );
                                                                                                                  
 /* if(gelo_control_if.translate_point && ucp[0]=='T')
  {
      gelo_control_if.translate_point(&touch_packet);
  } */
  if(elocontrol_XlateTouch && ucp[0]=='T')
  {
         elocontrol_XlateTouch(&touch_packet);
                                                                                                                  
  }
                                                                                                                  
#ifndef LKV_24
    status = elo_usb_submit_urb(urb, GFP_KERNEL);
                                                                                                                  
  if (status)
    {
                elo_printk(" failed to submit urb status %x ", status);
    }
#endif
}

//----------------------------------------------------------------------------

#ifndef LKV_24
struct elousb_device *hw_init(struct usb_interface *intf)
#else
struct elousb_device *hw_init(struct usb_device *dev, unsigned int ifnum)
#endif
{
                                                                                                                  
    struct elousb_device *device;
    int status;
    int pipe;
    struct usb_endpoint_descriptor *endpoint;
                                                                                                                  
#ifndef LKV_24
                                                                                                                  
        struct usb_host_interface *interface = intf->altsetting;
        struct usb_device *dev = interface_to_usbdev (intf);
          endpoint = &interface->endpoint[0].desc;
#else
        //struct usb_interface *intf = usb_ifnum_to_if(dev,ifnum);
        struct usb_interface_descriptor * interface_descriptor  = dev->actconfig->interface[ifnum].altsetting;
        endpoint = &interface_descriptor->endpoint[0];
                                                                                                                  
                                                                                                                  
    if(!endpoint)
    {
          elo_printk(KERN_ERR " could not get endpoint desc %x \n", endpoint);
        return NULL;
    }
#endif
                                                                                                                  
                                                                                                                  
        if  (USB_VENDOR_ID_ELOTOUCH == dev->descriptor.idVendor)
        {
                elo_printk(KERN_ERR " hw_init Claimed %x \n", dev->descriptor.idVendor);
        }
        else
        {
        elo_printk(KERN_ERR " hw_init Rejected %x \n", dev->descriptor.idVendor);
        return NULL;
        }
                                                                                                                  
                                                                                                                  
    // allocate and init context
    device = elo_kmalloc(sizeof(struct elousb_device), GFP_KERNEL);
                                                                                                                  
    if (!device) goto  error_exit;
    elo_memset(device, 0, sizeof(struct elousb_device));
    device->device = dev;
                                                                                                                  
#ifndef LKV_24
    device->interface = intf;
#endif
        elodev = device;
                                                                                                                  
    elousb_get_descriptors(device);
                                                                                                                  
                                                                                                                  
    // init urb
#ifndef LKV_24
    device->urb_buffer = elo_usb_buffer_alloc(dev, ELO_BUFFER_SIZE, GFP_ATOMIC, &device->urb_dma);
    if (!device->urb_buffer) goto error_exit;
#endif
                                                                                                                  
#ifndef LKV_24
    device->input_urb = elo_usb_alloc_urb(0, GFP_KERNEL);
    if (! device->input_urb) goto error_exit;
#else
    device->input_urb = elo_usb_alloc_urb(0);
    if (! device->input_urb) goto error_exit;
#endif
                                                                                                                  
    pipe = elo_usb_rcvintpipe(dev, endpoint->bEndpointAddress);
                                                                                                                  
    elo_usb_fill_int_urb(device->input_urb, dev, pipe, device->urb_buffer, 8, (usb_complete_t) urb_completion_irq, device, endpoint->bInterval);
                                                                                                                  
                                                                                                                  
                                                                                                                  
                                                                                                                  
#ifndef LKV_24
device->input_urb->transfer_dma = device->urb_dma;
    device->input_urb->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;
#endif
    if (!device->input_urb)  goto error_exit; // mn_note check on this check
                                                                                                                  
#ifndef LKV_24
    status = elo_usb_submit_urb(device->input_urb, GFP_KERNEL);
    elo_usb_set_intfdata(intf, device);
#else
    status = elo_usb_submit_urb(device->input_urb);
#endif
                                                                                                                  
    if (status)  goto error_exit;
                                                                                                                  
        elo_printk("Succesful Init of %x \n", dev->descriptor.idVendor);
    return device;
                                                                                                                  
error_exit:
                                                                                                                  
        elo_printk("failed to init device\n");
        hw_release(device);
        return NULL;
}

//----------------------------------------------------------------------------
// Implements module load initialize
int proj_init_module(void)
{
	int status;
	int retval;
	char szBuff[MAX_STR];

	struct proc_dir_entry *entry;

	sprintf( szBuff, "Init module registering %s major %d \n", elocontrol_name, elocontrol_major ) ;
	debugprintk(DBG_INPUT_PIPE,szBuff);

	entry=create_proc_entry( "elo", 0644, NULL ) ;
	if( NULL==entry ) return -1;
	entry->owner=THIS_MODULE;
	entry->read_proc=read_procmem;
//	entry->write_proc=write_procmem;

	// register the data device
	status=register_chrdev(elocontrol_major, elocontrol_name, &elocontrol_fops );
	
	if( status <0 )
	{
		printk(KERN_EMERG "device registration failed\n");
		return status;			
	}

	if(elocontrol_major ==0 ) elocontrol_major=status;

	sprintf( szBuff, "major assigned = %d \n", elocontrol_major);
	debugprintk(DBG_INPUT_PIPE,szBuff);

	// if eloconfig_major value is 0 it is automatically assigned
	// the assigned value can be read in /proc/devices
	// register the configuration information device	
	status=register_chrdev(eloconfig_major, eloconfig_name, &eloconfig_fops );
	
	if( status <0 )
	{
		printk(KERN_EMERG "device registration failed\n");
		return status;			
	}

	if(eloconfig_major ==0 ) eloconfig_major=status;

	sprintf( szBuff, "major assigned = %d \n", eloconfig_major);
	debugprintk(DBG_INPUT_PIPE,szBuff);

	// register the usb device
      
        retval = elo_usb_register(&elousb_driver);
                                                                                                                  
        if (retval)     return retval;
                                                                                                                  
//        gelo_control_if.translate_point = NULL;
       // elo_register_control(&elousbif) ;

	init_waitqueue_head(&elocontrol_wq);
	init_waitqueue_head(&elocontrol_wqgetpt);
	init_waitqueue_head(&eloconfig_wq);
	init_waitqueue_head(&eloserialcmd_wq);
	init_waitqueue_head(&eloserialrsp_wq);
	// register the serial smartset devices for exchanging data with the serial 
	// user mode module
	// we use 1. cmd 2. response
	//cmd
	status=register_chrdev(eloserialcmd_major, eloserialcmd_name, &eloserialcmd_fops );
	
	if( status <0 )
	{
		printk(KERN_EMERG "Serial cmd device registration failed\n");
		return status;			
	}

	if(eloserialcmd_major ==0 ) eloserialcmd_major=status;

	sprintf( szBuff, "major assignedto serial cmd = %d \n", eloserialcmd_major);
	debugprintk(DBG_INPUT_PIPE,szBuff);

	debugprintk( DBG_INPUT_PIPE, "init timer\n");

	init_timer(&timer);
	timer.expires = jiffies + SECONDS_COUNT ;
	timer.data = (unsigned long) &up_seconds;
	timer.function = my_timer_function ;
	add_timer( &timer );

/*	init_timer(&reset_data_timer);
	reset_data_timer.expires = jiffies + RESET_DATA_SECONDS_COUNT ;
	reset_data_timer.function = reset_data_timer_function ;
	add_timer( &reset_data_timer );*/

	databufferhead = databuffertail = 0 ;		
	InitValues() ;
	return 0;
}


//----------------------------------------------------------------------------
// Implements module unload free up
void proj_cleanup_module(void)
{
	int status ;
	char szBuff[ MAX_STR ] ;

	// If debugging is enabled print the function param
	sprintf( szBuff, "Cleanup module Unregistering %s %d \n", elocontrol_name, elocontrol_major );
	debugprintk(DBG_INPUT_PIPE, szBuff);
        
        // Unregister the USB driver 
        elo_usb_deregister(&elousb_driver);

	// unregister the char driver
	unregister_chrdev(elocontrol_major,elocontrol_name);
	unregister_chrdev(eloconfig_major,eloconfig_name);
	unregister_chrdev(eloserialcmd_major,eloserialcmd_name);
	
	// unregister the timer
	status = del_timer_sync( &timer ) ;
//	del_timer_sync( &reset_data_timer );

	remove_proc_entry( "elo", NULL ) ;
	return;
	
}

//----------------------------------------------------------------------------
module_init(proj_init_module);
module_exit(proj_cleanup_module);

//----------------------------------------------------------------------------

// Wrapper code

int elo_usb_control_msg(struct usb_device *dev, unsigned int pipe,
	__u8 request, __u8 requesttype, __u16 value, __u16 index,
	void *data, __u16 size, int timeout)
{

	return usb_control_msg(dev,  pipe,
	request, requesttype,  value, index,
	data,  size,  timeout);
}


#ifndef LKV_24
int elo_usb_submit_urb(struct urb *urb, int mem_flags)
{
	return usb_submit_urb(urb, mem_flags);
}


struct urb *elo_usb_alloc_urb(int iso_packets, int mem_flags)
{
	return usb_alloc_urb(iso_packets, mem_flags);
}
#else
int elo_usb_submit_urb(struct urb *urb)
{
	return usb_submit_urb(urb);
}


struct urb *elo_usb_alloc_urb(int iso_packets)
{
	return usb_alloc_urb(iso_packets);
}

#endif
//elo_usb_rcvctrlpipe

int elo_usb_unlink_urb(struct urb *urb)
{
 return usb_unlink_urb(urb);
}

#ifndef LKV_24
void * elo_usb_buffer_alloc(struct usb_device *dev, size_t size,
	int mem_flags, dma_addr_t *dma)
{
	return usb_buffer_alloc (dev,  size, mem_flags, dma);
}
#endif

int elo_printk(const char*fmt, ...)
{
	va_list args;
	char buf[81];
	int len;

	va_start(args, fmt);
	len = vsprintf(buf, fmt, args);
	va_end(args);
 	printk("%s",buf);
	return len;;
}


void elo_usb_fill_int_urb(struct urb *urb,
				     struct usb_device *dev,
				     unsigned int pipe,
				     void *transfer_buffer,
				     int buffer_length,
				     usb_complete_t complete,
				     void *context,
				     int interval)
{
	return usb_fill_int_urb (urb,dev, pipe, transfer_buffer,buffer_length,
				     complete,context,interval);
}

void * elo_kmalloc(size_t size, int priority)
{
       
	return kmalloc (size, priority);
      
}
//elo_usb_sndctrlpipe


#ifndef LKV_24
void elo_usb_set_intfdata(struct usb_interface *intf, void *data)
{
	return usb_set_intfdata (intf, data);
}

void *elo_usb_get_intfdata(struct usb_interface *intf)
{
	return usb_get_intfdata (intf);
}


void elo_usb_buffer_free(struct usb_device *dev, size_t size,
	void *addr, dma_addr_t dma)
{
	return usb_buffer_free (dev,size, addr, dma);
}
#endif

void elo_usb_deregister(struct usb_driver * driver)
{
	return usb_deregister(driver);
}

void *elo_memset(void *s, int c, size_t n)
{
  return memset(s, c,  n);
}
int elo_usb_register(struct usb_driver * driver)
{
	return usb_register(driver);
	
}

void elo_kfree(void * __ptr)
{
	return kfree (__ptr);
}

void elo_usb_free_urb(struct urb *urb)
{
	return usb_free_urb(urb);
}



//-------------------------------EOF---------------------------------------------
